# SpringBootApplication
This is the Basic Structure of the Project 
This is an imageHoster Project which is Built Using Spring 
This Application basically Displays Images with its Description and Tags
You can Register Yourself as a User and Login and can upload Images on the site.
The functionality of delete and Edit the picutre is also given 
